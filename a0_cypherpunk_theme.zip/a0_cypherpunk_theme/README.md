# ⚡ Agent Zero Cypherpunk Theme

A complete cypherpunk theming system for Agent Zero with animated backgrounds, 20 color themes, and rich UI customization.

## ✨ Features

- **20 Color Themes** - Matrix green, red, orange, cyan, synthwave, pastels, and more
- **Matrix Rain Effect** - Japanese hiragana + Greek characters
- **Fractal Plasma Effect** - Animated plasma background
- **Font Selector** - 5 monospace fonts (JetBrains, Fira Code, Space, Source, IBM Plex)
- **Inverted Selection** - Text highlighting uses inverted theme colors
- **Varied Message Colors** - User, Agent, and Tool messages have distinct colors
- **Rich Text Hierarchy** - Different colors for headings, bold, italic, links, quotes
- **Control Panel** - Easy access via ⚡ button in bottom-right corner
- **Persistent Settings** - All preferences saved to localStorage

## 📦 Installation

### Method 1: Automatic Install (Recommended)

1. Copy the `a0_cypherpunk_theme` folder to your Agent Zero projects directory:
   ```bash
   cp -r a0_cypherpunk_theme /path/to/agent-zero/usr/projects/
   ```

2. Run the installer:
   ```bash
   cd /path/to/agent-zero/usr/projects/a0_cypherpunk_theme
   python install.py
   ```

3. Refresh your browser with `Ctrl+Shift+R`

### Method 2: Manual Install

1. Copy the theme folder to your projects directory

2. Add this line before `</head>` in `/path/to/agent-zero/webui/index.html`:
   ```html
   <script src="/projects/a0_cypherpunk_theme/js/cypherpunk-integration.js" defer></script>
   ```

3. Hard refresh browser

## 🗑️ Uninstallation

```bash
python install.py --uninstall
```

Or manually remove the script tag from `index.html`.

## 🎮 Usage

After installation:

1. Click the **⚡** button in the bottom-right corner
2. Select a **background** (Matrix, Fractal, or Off)
3. Adjust **opacity** and **speed** sliders
4. Choose a **font** from the 5 options
5. Pick a **theme** from the 20 available

All settings are saved automatically!

## 🎨 Available Themes

### Cypherpunk (Dark Neon)
- 🟢 Matrix (green)
- 🔴 Red
- 🟠 Orange  
- 💛 Yellow
- 🔵 Cyan
- 💙 Blue
- 💜 Indigo
- 🟣 Violet

### Cypherpastel (Soft Neon)
- 🌸 Pink
- 🍃 Mint
- 💜 Lavender
- 🍑 Peach
- 🌤️ Sky
- 🍋 Lemon
- 🪸 Coral
- 🌊 Aqua

### Synthwave (Retro)
- 🎹 Synthwave
- 💎 Synthwave Aqua
- ⚡ Synthwave Hybrid
- 💻 Synthwave Terminal

## 📁 File Structure

```
a0_cypherpunk_theme/
├── css/
│   ├── themes.css       # 20 theme color palettes
│   └── cypherpunk.css   # UI styling rules
├── js/
│   ├── cypherpunk-integration.js  # Main entry point
│   ├── matrix-rain.js   # Matrix rain effect
│   └── fractal-bg.js    # Fractal plasma effect
├── theming-guide.html   # Comprehensive documentation site
├── install.py           # Auto-installer
└── README.md            # This file
```

## 🔧 Customization

### Adding New Themes

Edit `css/themes.css` and add a new theme block:

```css
:root[data-theme="my-theme"] {
    --cp-primary: #ff00ff;
    --cp-secondary: #cc00cc;
    --cp-accent: #ff66ff;
    /* ... other variables */
}
```

Then add it to `THEMES` object in `js/cypherpunk-integration.js`:

```javascript
'my-theme': { name: '🎨 My Theme', color: '#ff00ff' },
```

### CSS Variables Reference

| Variable | Purpose |
|----------|--------|
| `--cp-primary` | Main color, H1 headings |
| `--cp-secondary` | H2 headings, buttons |
| `--cp-accent` | H3, bold text |
| `--cp-tertiary` | H4, italic text |
| `--cp-text` | Default text color |
| `--cp-msg-user` | User message color |
| `--cp-msg-agent` | Agent message color |
| `--cp-msg-tool` | Tool message color |
| `--cp-select-bg` | Selection background |
| `--cp-select-text` | Selection text (dark) |

## ⚠️ Important Notes

- This theme does not modify core Agent Zero files
- All changes are additive via CSS injection
- Safe to update Agent Zero without losing theme
- Uses `/projects/` path which A0 serves automatically

## 🐛 Troubleshooting

**Theme not loading?**
- Hard refresh with `Ctrl+Shift+R`
- Check browser console for errors
- Verify install.py ran successfully

**Icons broken?**
- Make sure `.material-symbols-outlined` is not being overridden
- Check CSS for wildcard font-family rules

**Matrix rain not visible?**
- Check z-index conflicts
- Verify canvas has `display: block`
- Try increasing opacity

## 📜 License

MIT License - Feel free to modify and share!

## 💚 Credits

Built for the Agent Zero community with cypherpunk spirit ⚡
