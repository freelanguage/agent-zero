#!/usr/bin/env python3
"""
Agent Zero Cypherpunk Theme Installer
Automatically patches index.html to load the theme
"""

import os
import sys
import shutil
from datetime import datetime
from pathlib import Path

# Configuration
SCRIPT_TAG = '<script src="/projects/a0_cypherpunk_theme/js/cypherpunk-integration.js" defer></script>'
SCRIPT_MARKER = 'cypherpunk-integration.js'

def find_agent_zero_root():
    """Find the Agent Zero root directory"""
    # Start from current script location
    current = Path(__file__).resolve().parent
    
    # Walk up looking for webui/index.html
    for _ in range(10):  # Max 10 levels up
        webui_index = current / 'webui' / 'index.html'
        if webui_index.exists():
            return current
        
        # Also check if we're in usr/projects/theme_name
        potential_root = current.parent.parent.parent
        webui_index = potential_root / 'webui' / 'index.html'
        if webui_index.exists():
            return potential_root
            
        current = current.parent
    
    return None

def backup_file(filepath):
    """Create a timestamped backup"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = f"{filepath}.{timestamp}.bak"
    shutil.copy2(filepath, backup_path)
    return backup_path

def install(index_path):
    """Install the theme by patching index.html"""
    print(f"📄 Found index.html: {index_path}")
    
    with open(index_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if already installed
    if SCRIPT_MARKER in content:
        print("⚠️  Theme already installed! Use --reinstall to force.")
        return False
    
    # Create backup
    backup = backup_file(index_path)
    print(f"💾 Backup created: {backup}")
    
    # Find </head> and insert before it
    if '</head>' not in content:
        print("❌ Error: Could not find </head> tag in index.html")
        return False
    
    new_content = content.replace(
        '</head>',
        f'    {SCRIPT_TAG}\n</head>'
    )
    
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("✅ Theme installed successfully!")
    print("")
    print("🔄 Hard refresh your browser with Ctrl+Shift+R")
    print("⚡ Click the lightning bolt button to open the theme panel")
    return True

def uninstall(index_path):
    """Uninstall the theme by removing the script tag"""
    print(f"📄 Found index.html: {index_path}")
    
    with open(index_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if SCRIPT_MARKER not in content:
        print("⚠️  Theme not installed, nothing to remove.")
        return False
    
    # Create backup
    backup = backup_file(index_path)
    print(f"💾 Backup created: {backup}")
    
    # Remove the script tag line
    lines = content.split('\n')
    new_lines = [line for line in lines if SCRIPT_MARKER not in line]
    new_content = '\n'.join(new_lines)
    
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("✅ Theme uninstalled successfully!")
    print("🔄 Hard refresh your browser with Ctrl+Shift+R")
    return True

def main():
    print("")
    print("⚡ Agent Zero Cypherpunk Theme Installer")
    print("=" * 40)
    print("")
    
    # Parse arguments
    uninstall_mode = '--uninstall' in sys.argv or '-u' in sys.argv
    reinstall_mode = '--reinstall' in sys.argv or '-r' in sys.argv
    
    # Find Agent Zero root
    a0_root = find_agent_zero_root()
    
    if not a0_root:
        print("❌ Error: Could not find Agent Zero installation.")
        print("")
        print("Make sure this folder is in:")
        print("  /path/to/agent-zero/usr/projects/a0_cypherpunk_theme/")
        print("")
        print("Or specify the path manually:")
        print("  python install.py /path/to/agent-zero")
        sys.exit(1)
    
    print(f"📂 Agent Zero root: {a0_root}")
    
    index_path = a0_root / 'webui' / 'index.html'
    
    if not index_path.exists():
        print(f"❌ Error: index.html not found at {index_path}")
        sys.exit(1)
    
    if uninstall_mode:
        success = uninstall(index_path)
    else:
        if reinstall_mode:
            # First uninstall, then install
            uninstall(index_path)
        success = install(index_path)
    
    print("")
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()
