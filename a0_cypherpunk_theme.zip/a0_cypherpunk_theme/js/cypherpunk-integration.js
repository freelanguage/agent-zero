/**
 * Agent Zero Cypherpunk Theme
 * Full control panel with font selector, BG switcher, themes
 */

(function() {
    'use strict';

    const THEMES = {
        'cypherpunk': { name: '🟢 Matrix', color: '#00ff9f' },
        'cypherpunk-red': { name: '🔴 Red', color: '#ff3333' },
        'cypherpunk-orange': { name: '🟠 Orange', color: '#ff8800' },
        'cypherpunk-yellow': { name: '💛 Yellow', color: '#ffdd00' },
        'cypherpunk-cyan': { name: '🔵 Cyan', color: '#00ddff' },
        'cypherpunk-blue': { name: '💙 Blue', color: '#4488ff' },
        'cypherpunk-indigo': { name: '💜 Indigo', color: '#8855ff' },
        'cypherpunk-violet': { name: '🟣 Violet', color: '#cc44ff' },
        'cypherpastel-pink': { name: '🌸 Pink', color: '#ff99cc' },
        'cypherpastel-mint': { name: '🍃 Mint', color: '#7fffd4' },
        'cypherpastel-lavender': { name: '💜 Lav', color: '#d4b8ff' },
        'cypherpastel-peach': { name: '🍑 Peach', color: '#ffb899' },
        'cypherpastel-sky': { name: '🌤️ Sky', color: '#99d4ff' },
        'cypherpastel-lemon': { name: '🍋 Lemon', color: '#ffee88' },
        'cypherpastel-coral': { name: '🪸 Coral', color: '#ff9999' },
        'cypherpastel-aqua': { name: '🌊 Aqua', color: '#80ffe8' },
        'synthwave': { name: '🎹 Synth', color: '#ff2a6d' },
        'synthwave-aqua': { name: '💎 S-Aqua', color: '#00e5ff' },
        'synthwave-hybrid': { name: '⚡ S-Hyb', color: '#ff2a6d' },
        'synthwave-terminal': { name: '💻 S-Term', color: '#00ff41' },
    };

    const FONTS = {
        'jetbrains': { name: 'JetBrains', family: 'JetBrains Mono' },
        'fira': { name: 'Fira Code', family: 'Fira Code' },
        'space': { name: 'Space', family: 'Space Mono' },
        'source': { name: 'Source', family: 'Source Code Pro' },
        'ibm': { name: 'IBM Plex', family: 'IBM Plex Mono' }
    };

    // State
    let currentTheme = 'cypherpunk';
    let currentFont = 'jetbrains';
    let panelOpen = false;
    let bgType = 'matrix';
    let bgOpacity = 80;
    let bgSpeed = 50;

    function loadSettings() {
        currentTheme = localStorage.getItem('a0-theme') || 'cypherpunk';
        currentFont = localStorage.getItem('a0-font') || 'jetbrains';
        bgType = localStorage.getItem('a0-bg-type') || 'matrix';
        bgOpacity = parseInt(localStorage.getItem('a0-bg-opacity')) || 80;
        bgSpeed = parseInt(localStorage.getItem('a0-bg-speed')) || 50;
    }

    function getColor() {
        return THEMES[currentTheme]?.color || '#00ff9f';
    }

    function applyTheme(themeId) {
        currentTheme = themeId;
        localStorage.setItem('a0-theme', themeId);
        
        document.documentElement.setAttribute('data-theme', themeId);
        document.body.classList.add('cypherpunk-active');
        
        const color = getColor();
        document.documentElement.style.setProperty('--cp-primary', color);
        document.documentElement.style.setProperty('--color-primary', color);
        
        if (window.MatrixRain) window.MatrixRain.syncWithTheme();
        if (window.FractalBg) window.FractalBg.syncWithTheme();
        
        updatePanelUI();
    }

    function applyFont(fontId) {
        currentFont = fontId;
        localStorage.setItem('a0-font', fontId);
        
        const font = FONTS[fontId];
        if (!font) return;
        
        // Method 1: Data attribute
        document.documentElement.setAttribute('data-font', fontId);
        
        // Method 2: Direct body style
        document.body.style.fontFamily = `'${font.family}', monospace`;
        
        // Method 3: CSS variables
        document.documentElement.style.setProperty('--font-main', `'${font.family}', monospace`);
        document.documentElement.style.setProperty('--font-code', `'${font.family}', monospace`);
        
        updateFontButtons();
    }

    function updatePanelUI() {
        const color = getColor();
        
        const btn = document.getElementById('cp-toggle');
        if (btn) {
            btn.style.borderColor = color;
            btn.style.color = color;
            btn.style.boxShadow = `0 0 20px ${color}80`;
        }
        
        const panel = document.getElementById('cp-panel');
        if (panel) {
            panel.style.borderColor = color;
        }
        
        // Update all sliders
        document.querySelectorAll('#cp-panel input[type="range"]').forEach(slider => {
            slider.style.accentColor = color;
        });
        
        updateThemeButtons();
        updateBgButtons();
        updateFontButtons();
    }

    function updateThemeButtons() {
        document.querySelectorAll('.cp-theme-btn').forEach(btn => {
            const id = btn.dataset.theme;
            const theme = THEMES[id];
            const isActive = id === currentTheme;
            btn.style.background = isActive ? `${theme.color}25` : 'rgba(0,0,0,0.3)';
            btn.style.borderColor = isActive ? theme.color : `${theme.color}50`;
        });
    }

    function updateBgButtons() {
        const color = getColor();
        ['matrix', 'fractal', 'off'].forEach(type => {
            const btn = document.getElementById(`cp-bg-${type}`);
            if (btn) {
                const isActive = bgType === type;
                btn.style.background = isActive ? `${color}30` : 'rgba(0,0,0,0.3)';
                btn.style.borderColor = isActive ? color : `${color}40`;
            }
        });
    }

    function updateFontButtons() {
        const color = getColor();
        document.querySelectorAll('.cp-font-btn').forEach(btn => {
            const id = btn.dataset.font;
            const isActive = id === currentFont;
            btn.style.background = isActive ? `${color}30` : 'rgba(0,0,0,0.3)';
            btn.style.borderColor = isActive ? color : `${color}40`;
        });
    }

    function setBgType(type) {
        bgType = type;
        localStorage.setItem('a0-bg-type', type);
        
        if (window.MatrixRain) window.MatrixRain.stop();
        if (window.FractalBg) window.FractalBg.stop();
        
        if (type === 'matrix' && window.MatrixRain) {
            window.MatrixRain.start();
        } else if (type === 'fractal' && window.FractalBg) {
            window.FractalBg.start();
        }
        
        updateBgButtons();
    }

    function setBgOpacity(val) {
        bgOpacity = val;
        localStorage.setItem('a0-bg-opacity', val);
        if (window.MatrixRain) window.MatrixRain.setOpacity(val / 100);
        if (window.FractalBg) window.FractalBg.setOpacity(val / 100);
    }

    function setBgSpeed(val) {
        bgSpeed = val;
        localStorage.setItem('a0-bg-speed', val);
        if (window.MatrixRain) window.MatrixRain.setSpeed(val);
        if (window.FractalBg) window.FractalBg.setSpeed(val);
    }

    function createUI() {
        // Load Google Fonts
        const fontLink = document.createElement('link');
        fontLink.rel = 'stylesheet';
        fontLink.href = 'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Fira+Code&family=Space+Mono&family=Source+Code+Pro&family=IBM+Plex+Mono&display=swap';
        document.head.appendChild(fontLink);

        // Load CSS
        ['themes.css', 'cypherpunk.css'].forEach(file => {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = `/projects/a0_rice_muffins/css/${file}`;
            document.head.appendChild(link);
        });

        // Load background scripts
        const matrixScript = document.createElement('script');
        matrixScript.src = '/projects/a0_rice_muffins/js/matrix-rain.js';
        document.body.appendChild(matrixScript);
        
        const fractalScript = document.createElement('script');
        fractalScript.src = '/projects/a0_rice_muffins/js/fractal-bg.js';
        document.body.appendChild(fractalScript);

        setTimeout(() => {
            const opacityVal = bgOpacity / 100;
            if (window.MatrixRain) {
                window.MatrixRain.setOpacity(opacityVal);
                window.MatrixRain.setSpeed(bgSpeed);
                window.MatrixRain.syncWithTheme();
            }
            if (window.FractalBg) {
                window.FractalBg.setOpacity(opacityVal);
                window.FractalBg.setSpeed(bgSpeed);
                window.FractalBg.syncWithTheme();
            }
            setBgType(bgType);
        }, 200);

        const color = getColor();

        // Toggle button
        const btn = document.createElement('button');
        btn.id = 'cp-toggle';
        btn.innerHTML = '⚡';
        btn.title = 'Cypherpunk Panel';
        btn.style.cssText = `
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 54px;
            height: 54px;
            border-radius: 50%;
            border: 3px solid ${color};
            background: rgba(0, 10, 5, 0.95);
            color: ${color};
            font-size: 26px;
            cursor: pointer;
            z-index: 99999;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 20px ${color}80;
            transition: transform 0.2s;
        `;
        btn.onmouseenter = () => btn.style.transform = 'scale(1.1)';
        btn.onmouseleave = () => btn.style.transform = 'scale(1)';
        btn.onclick = () => {
            panelOpen = !panelOpen;
            document.getElementById('cp-panel').style.display = panelOpen ? 'block' : 'none';
        };

        // Panel
        const panel = document.createElement('div');
        panel.id = 'cp-panel';
        panel.style.cssText = `
            position: fixed;
            bottom: 90px;
            right: 24px;
            width: 300px;
            max-height: 80vh;
            background: rgba(0, 10, 5, 0.97);
            border: 2px solid ${color};
            border-radius: 12px;
            padding: 14px;
            z-index: 99998;
            display: none;
            overflow-y: auto;
            font-family: monospace;
            box-shadow: 0 0 40px ${color}40;
        `;

        panel.innerHTML = `
            <div style="color:${color};font-size:13px;font-weight:bold;margin-bottom:12px;letter-spacing:1px;">
                ⚡ CYPHERPUNK
            </div>
            
            <!-- Background Switcher -->
            <div style="background:rgba(0,0,0,0.3);padding:10px;border-radius:8px;margin-bottom:10px;">
                <div style="color:${color};font-size:10px;margin-bottom:6px;letter-spacing:1px;">BACKGROUND</div>
                <div style="display:flex;gap:5px;margin-bottom:8px;">
                    <button id="cp-bg-matrix" class="cp-bg-btn" style="
                        flex:1;padding:7px;border-radius:5px;cursor:pointer;
                        background:${bgType === 'matrix' ? color + '30' : 'rgba(0,0,0,0.3)'};
                        border:1px solid ${bgType === 'matrix' ? color : color + '40'};
                        color:${color};font-size:10px;font-family:monospace;
                    ">💊 Matrix</button>
                    <button id="cp-bg-fractal" class="cp-bg-btn" style="
                        flex:1;padding:7px;border-radius:5px;cursor:pointer;
                        background:${bgType === 'fractal' ? color + '30' : 'rgba(0,0,0,0.3)'};
                        border:1px solid ${bgType === 'fractal' ? color : color + '40'};
                        color:${color};font-size:10px;font-family:monospace;
                    ">🌀 Fractal</button>
                    <button id="cp-bg-off" class="cp-bg-btn" style="
                        flex:1;padding:7px;border-radius:5px;cursor:pointer;
                        background:${bgType === 'off' ? color + '30' : 'rgba(0,0,0,0.3)'};
                        border:1px solid ${bgType === 'off' ? color : color + '40'};
                        color:${color};font-size:10px;font-family:monospace;
                    ">⬛ Off</button>
                </div>
                <div style="margin-bottom:6px;">
                    <label style="color:${color}99;font-size:9px;">OPACITY: <span id="cp-opacity-val">${bgOpacity}%</span></label>
                    <input type="range" id="cp-opacity" min="20" max="100" value="${bgOpacity}" 
                           style="width:100%;margin-top:3px;accent-color:${color};height:4px;">
                </div>
                <div>
                    <label style="color:${color}99;font-size:9px;">SPEED: <span id="cp-speed-val">${bgSpeed}ms</span></label>
                    <input type="range" id="cp-speed" min="20" max="100" value="${bgSpeed}" 
                           style="width:100%;margin-top:3px;accent-color:${color};height:4px;">
                </div>
            </div>
            
            <!-- Font Selector -->
            <div style="background:rgba(0,0,0,0.3);padding:10px;border-radius:8px;margin-bottom:10px;">
                <div style="color:${color};font-size:10px;margin-bottom:6px;letter-spacing:1px;">FONT</div>
                <div style="display:flex;flex-wrap:wrap;gap:4px;" id="cp-fonts"></div>
            </div>
            
            <!-- Themes -->
            <div style="color:${color};font-size:10px;margin-bottom:6px;letter-spacing:1px;">THEMES</div>
            <div id="cp-themes" style="display:grid;grid-template-columns:1fr 1fr;gap:4px;"></div>
        `;

        document.body.appendChild(btn);
        document.body.appendChild(panel);

        // Add font buttons
        const fontsDiv = document.getElementById('cp-fonts');
        Object.entries(FONTS).forEach(([id, font]) => {
            const fontBtn = document.createElement('button');
            fontBtn.className = 'cp-font-btn';
            fontBtn.dataset.font = id;
            fontBtn.textContent = font.name;
            fontBtn.style.cssText = `
                padding: 6px 10px;
                background: ${id === currentFont ? color + '30' : 'rgba(0,0,0,0.3)'};
                border: 1px solid ${id === currentFont ? color : color + '40'};
                color: ${color};
                font-size: 9px;
                border-radius: 4px;
                cursor: pointer;
                font-family: '${font.family}', monospace;
            `;
            fontBtn.onclick = () => applyFont(id);
            fontsDiv.appendChild(fontBtn);
        });

        // Add theme buttons
        const themesDiv = document.getElementById('cp-themes');
        Object.entries(THEMES).forEach(([id, theme]) => {
            const themeBtn = document.createElement('button');
            themeBtn.className = 'cp-theme-btn';
            themeBtn.dataset.theme = id;
            themeBtn.textContent = theme.name;
            themeBtn.style.cssText = `
                padding: 6px 4px;
                background: ${id === currentTheme ? theme.color + '25' : 'rgba(0,0,0,0.3)'};
                border: 1px solid ${id === currentTheme ? theme.color : theme.color + '50'};
                color: ${theme.color};
                font-size: 9px;
                border-radius: 4px;
                cursor: pointer;
                font-family: monospace;
            `;
            themeBtn.onclick = () => {
                applyTheme(id);
            };
            themesDiv.appendChild(themeBtn);
        });

        // Event listeners
        document.getElementById('cp-bg-matrix').onclick = () => setBgType('matrix');
        document.getElementById('cp-bg-fractal').onclick = () => setBgType('fractal');
        document.getElementById('cp-bg-off').onclick = () => setBgType('off');
        
        document.getElementById('cp-opacity').oninput = (e) => {
            setBgOpacity(parseInt(e.target.value));
            document.getElementById('cp-opacity-val').textContent = e.target.value + '%';
        };
        
        document.getElementById('cp-speed').oninput = (e) => {
            setBgSpeed(parseInt(e.target.value));
            document.getElementById('cp-speed-val').textContent = e.target.value + 'ms';
        };

        // Close on outside click
        document.addEventListener('click', (e) => {
            const panel = document.getElementById('cp-panel');
            const btn = document.getElementById('cp-toggle');
            if (panelOpen && !panel.contains(e.target) && e.target !== btn) {
                panelOpen = false;
                panel.style.display = 'none';
            }
        });
    }

    function init() {
        loadSettings();
        createUI();
        applyTheme(currentTheme);
        applyFont(currentFont);
        console.log('🎨 Cypherpunk:', currentTheme, 'Font:', currentFont);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
