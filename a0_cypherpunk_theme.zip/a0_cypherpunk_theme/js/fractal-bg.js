/**
 * Agent Zero Fractal Background - Full Resolution
 * Sharp plasma effect with theme colors
 */

(function() {
    'use strict';

    const THEME_COLORS = {
        'cypherpunk': { r: 0, g: 255, b: 159 },
        'cypherpunk-red': { r: 255, g: 60, b: 60 },
        'cypherpunk-orange': { r: 255, g: 140, b: 0 },
        'cypherpunk-yellow': { r: 255, g: 225, b: 0 },
        'cypherpunk-cyan': { r: 0, g: 225, b: 255 },
        'cypherpunk-blue': { r: 70, g: 140, b: 255 },
        'cypherpunk-indigo': { r: 140, g: 90, b: 255 },
        'cypherpunk-violet': { r: 210, g: 70, b: 255 },
        'cypherpastel-pink': { r: 255, g: 160, b: 210 },
        'cypherpastel-mint': { r: 130, g: 255, b: 215 },
        'cypherpastel-lavender': { r: 215, g: 185, b: 255 },
        'cypherpastel-peach': { r: 255, g: 190, b: 155 },
        'cypherpastel-sky': { r: 155, g: 215, b: 255 },
        'cypherpastel-lemon': { r: 255, g: 240, b: 130 },
        'cypherpastel-coral': { r: 255, g: 155, b: 155 },
        'cypherpastel-aqua': { r: 130, g: 255, b: 235 },
        'synthwave': { r: 255, g: 45, b: 110 },
        'synthwave-aqua': { r: 0, g: 230, b: 255 },
        'synthwave-hybrid': { r: 255, g: 45, b: 110 },
        'synthwave-terminal': { r: 0, g: 255, b: 70 }
    };

    let canvas, ctx;
    let animationId = null;
    let isRunning = false;
    let time = 0;
    
    let baseColor = { r: 0, g: 255, b: 159 };
    let speed = 50;
    let opacity = 0.7;

    // Render at 1/2 resolution for balance of quality and performance
    let scale = 2;
    let w, h;
    let imageData, data;

    function init() {
        canvas = document.createElement('canvas');
        canvas.id = 'fractal-bg';
        canvas.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: -1;
            pointer-events: none;
            opacity: ${opacity};
            display: none;
            background: #000;
            image-rendering: crisp-edges;
            image-rendering: pixelated;
        `;
        document.body.insertBefore(canvas, document.body.firstChild);
        ctx = canvas.getContext('2d', { alpha: false });
        ctx.imageSmoothingEnabled = false;

        window.addEventListener('resize', resize);
        resize();
        syncTheme();
    }

    function resize() {
        w = Math.ceil(window.innerWidth / scale);
        h = Math.ceil(window.innerHeight / scale);
        canvas.width = w;
        canvas.height = h;
        imageData = ctx.createImageData(w, h);
        data = imageData.data;
    }

    function draw() {
        const t = time;
        
        for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
                // Fast plasma calculation
                const v1 = Math.sin(x * 0.03 + t);
                const v2 = Math.sin(y * 0.03 + t * 0.7);
                const v3 = Math.sin((x + y) * 0.02 + t * 0.5);
                const v4 = Math.sin(Math.sqrt((x - w/2) * (x - w/2) + (y - h/2) * (y - h/2)) * 0.03 - t * 0.8);
                
                const v = (v1 + v2 + v3 + v4 + 4) / 8; // 0 to 1
                
                const idx = (y * w + x) * 4;
                
                // Intensity-based coloring
                const intensity = v * v; // Square for more contrast
                data[idx] = Math.floor(baseColor.r * intensity * 0.6);
                data[idx + 1] = Math.floor(baseColor.g * intensity * 0.6);
                data[idx + 2] = Math.floor(baseColor.b * intensity * 0.6);
                data[idx + 3] = 255;
            }
        }

        ctx.putImageData(imageData, 0, 0);
        time += 0.025;
    }

    function animate() {
        if (!isRunning) return;
        draw();
        animationId = setTimeout(() => requestAnimationFrame(animate), speed);
    }

    function start() {
        if (isRunning) return;
        isRunning = true;
        canvas.style.display = 'block';
        animate();
    }

    function stop() {
        isRunning = false;
        if (animationId) clearTimeout(animationId);
        canvas.style.display = 'none';
    }

    function setOpacity(val) {
        opacity = val;
        canvas.style.opacity = val;
    }

    function setSpeed(val) {
        speed = val;
    }

    function syncTheme() {
        const theme = localStorage.getItem('a0-theme') || 'cypherpunk';
        if (THEME_COLORS[theme]) {
            baseColor = THEME_COLORS[theme];
        }
    }

    window.FractalBg = {
        start, stop,
        toggle: () => { isRunning ? stop() : start(); return isRunning; },
        setOpacity, setSpeed,
        syncWithTheme: syncTheme,
        isEnabled: () => isRunning
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
