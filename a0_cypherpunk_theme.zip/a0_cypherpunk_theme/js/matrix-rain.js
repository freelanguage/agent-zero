/**
 * Agent Zero Matrix Rain
 * Japanese Hiragana + Greek Letters
 */

(function() {
    'use strict';

    const THEME_COLORS = {
        'cypherpunk': { bright: '#00ffaa', main: '#00dd88', dim: '#008855' },
        'cypherpunk-red': { bright: '#ff6666', main: '#ff3333', dim: '#aa2222' },
        'cypherpunk-orange': { bright: '#ffaa55', main: '#ff8800', dim: '#aa5500' },
        'cypherpunk-yellow': { bright: '#ffff66', main: '#ffdd00', dim: '#aaaa00' },
        'cypherpunk-cyan': { bright: '#66ffff', main: '#00ddff', dim: '#0099aa' },
        'cypherpunk-blue': { bright: '#88bbff', main: '#4488ff', dim: '#3355aa' },
        'cypherpunk-indigo': { bright: '#aa88ff', main: '#8855ff', dim: '#5533aa' },
        'cypherpunk-violet': { bright: '#ee88ff', main: '#cc44ff', dim: '#8833aa' },
        'cypherpastel-pink': { bright: '#ffccee', main: '#ff99cc', dim: '#cc6699' },
        'cypherpastel-mint': { bright: '#aaffee', main: '#77ffcc', dim: '#44aa88' },
        'cypherpastel-lavender': { bright: '#eeccff', main: '#cc99ff', dim: '#9966cc' },
        'cypherpastel-peach': { bright: '#ffddcc', main: '#ffbb99', dim: '#cc8866' },
        'cypherpastel-sky': { bright: '#ccddff', main: '#99bbff', dim: '#6688cc' },
        'cypherpastel-lemon': { bright: '#ffffaa', main: '#ffff66', dim: '#aaaa44' },
        'cypherpastel-coral': { bright: '#ffcccc', main: '#ff9999', dim: '#cc6666' },
        'cypherpastel-aqua': { bright: '#aaffff', main: '#77ffee', dim: '#44ccaa' },
        'synthwave': { bright: '#ff6699', main: '#ff2266', dim: '#aa1144' },
        'synthwave-aqua': { bright: '#66ffff', main: '#00ddff', dim: '#0099aa' },
        'synthwave-hybrid': { bright: '#ff66aa', main: '#ff2266', dim: '#00ccdd' },
        'synthwave-terminal': { bright: '#66ff88', main: '#00ff44', dim: '#00aa33' }
    };

    // Japanese Hiragana + Greek letters
    const HIRAGANA = 'あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん';
    const GREEK = 'αβγδεζηθικλμνξοπρστυφχψωΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ';
    const CHARS = HIRAGANA + GREEK;

    let canvas, ctx;
    let columns = [];
    let animationId = null;
    let isRunning = false;
    
    let colors = { bright: '#00ffaa', main: '#00dd88', dim: '#008855' };
    let fontSize = 18;
    let speed = 45;
    let opacity = 0.9;
    let columnSpacing = 28; // More spread out

    function init() {
        canvas = document.createElement('canvas');
        canvas.id = 'matrix-rain';
        canvas.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: -1;
            pointer-events: none;
            opacity: ${opacity};
            background: #000;
        `;
        document.body.insertBefore(canvas, document.body.firstChild);
        ctx = canvas.getContext('2d');

        window.addEventListener('resize', resize);
        resize();
        syncTheme();
        start();
    }

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        // More spread out columns
        const numCols = Math.floor(canvas.width / columnSpacing);
        columns = [];
        for (let i = 0; i < numCols; i++) {
            columns[i] = {
                x: i * columnSpacing + (columnSpacing / 2),
                y: Math.random() * canvas.height,
                speed: 0.8 + Math.random() * 1.2, // Slower speed range
                length: Math.floor(12 + Math.random() * 20), // Longer trails
                chars: generateChars(35)
            };
        }
    }

    function generateChars(len) {
        let result = [];
        for (let i = 0; i < len; i++) {
            result.push(CHARS[Math.floor(Math.random() * CHARS.length)]);
        }
        return result;
    }

    function draw() {
        // Slower fade = longer trails
        ctx.fillStyle = 'rgba(0, 0, 0, 0.06)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.font = `bold ${fontSize}px sans-serif`;
        ctx.textBaseline = 'top';

        for (let i = 0; i < columns.length; i++) {
            const col = columns[i];
            
            // Draw trail
            for (let j = 0; j < col.length; j++) {
                const charY = col.y - (j * fontSize);
                
                if (charY < -fontSize || charY > canvas.height) continue;
                
                // Head = bright, body = main, tail = dim
                if (j === 0) {
                    ctx.fillStyle = colors.bright;
                } else if (j < 4) {
                    ctx.fillStyle = colors.main;
                } else {
                    ctx.fillStyle = colors.dim;
                }
                
                const char = col.chars[j % col.chars.length];
                ctx.fillText(char, col.x, charY);
            }

            // Move down
            col.y += col.speed;

            // Random character change
            if (Math.random() > 0.92) {
                col.chars[0] = CHARS[Math.floor(Math.random() * CHARS.length)];
            }

            // Reset when off screen
            if (col.y - (col.length * fontSize) > canvas.height) {
                col.y = -fontSize * 2;
                col.speed = 0.8 + Math.random() * 1.2;
                col.length = Math.floor(12 + Math.random() * 20);
                col.chars = generateChars(35);
            }
        }
    }

    function animate() {
        if (!isRunning) return;
        draw();
        animationId = setTimeout(() => requestAnimationFrame(animate), speed);
    }

    function start() {
        if (isRunning) return;
        isRunning = true;
        canvas.style.display = 'block';
        animate();
    }

    function stop() {
        isRunning = false;
        if (animationId) clearTimeout(animationId);
        canvas.style.display = 'none';
    }

    function setOpacity(val) {
        opacity = val;
        canvas.style.opacity = val;
    }

    function setSpeed(val) {
        speed = val;
    }

    function syncTheme() {
        const theme = localStorage.getItem('a0-theme') || 'cypherpunk';
        if (THEME_COLORS[theme]) {
            colors = THEME_COLORS[theme];
        }
    }

    window.MatrixRain = {
        start, stop,
        toggle: () => { isRunning ? stop() : start(); return isRunning; },
        setColor: (c) => { colors.main = c; },
        setOpacity, setSpeed,
        syncWithTheme: syncTheme,
        isEnabled: () => isRunning
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
